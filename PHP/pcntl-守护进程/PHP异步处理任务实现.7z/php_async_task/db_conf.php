<?php
/**
 * 数据库配置
 */

return array(
  'database_type' => 'mysql',
  'database_name' => 'testtask',
  'server' => '127.0.0.1',
  'username' => 'root',
  'password' => 'root',

  // [optional]
  'charset' => 'utf8',
  'port' => 3306,
  // [optional] Table prefix
  'prefix' => ''
);