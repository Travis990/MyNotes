<?php
include './lib/Upload.php'; # 文件上传类, 详细使用文档: https://github.com/aileshe/Upload/blob/master/README.md
include './lib/Medoo.php';  # Medoo 详细使用文档: https://medoo.in/doc
include './function.php';

$db = M(); # 获得数据库操作句柄

$upload = new \Dj\Upload();
$filelist = $upload->save('./upload', [
	'ext'=>'xls'
]);
if(is_array($filelist)){
	# 文件就上传
	$xls_file_path = $filelist['savepath']; # 返回文件在服务器上的绝对路径

	# 添加任务信息到数据库中
	$db->insert(
		'tasklist', # 数据库表名
		[
			'name' => $xls_file_path
		]
	);
	
	# 立即返回给前台成功信息
	echo '{"code":200}';
	
	# 创建 守护进程, 以下代码会在后台继续执行直到完成后会自动退出
	$pid = pcntl_fork();
	if ($pid < 0) 
	{
		exit(0); # fork子进程失败 -1
	}
	elseif($pid)
	{ # 父进程
		exit(0); 
	}
	else
	{ # 子进程 0
		$sid = posix_setsid(); # 让子进程升级为会话
		if ($sid < 0) exit;

		chdir('./'); # 设置工作路径

		umask(0); # 设置权限掩码 umask

		# 关闭用不到的文件描述符
		fclose(STDIN);
		fclose(STDOUT);
		fclose(STDERR);

		# *执行核心代码

		//  do something ...
		// 数据处理, 例如: 导入大量数据需要耗很长时间的就放在这里异步执行..
    
    sleep(20); # 睡眠 20 秒, 这里是为了演示效果, 做正事时记得去掉哈, 哈哈

    # 注意: 这里有一个很重要的"问题", 数据库连接对象在pcntl_fork()的子进程内已经断开! 因此必须重新初始化POD对象
    # 昨晚就因为这个问题搞到了凌晨两点, 亚南要注意下哦! 
    // 数据库句柄重新初始化 Start
    $db = new \Medoo\Medoo(include './db_conf.php');
    // 数据库句柄重新初始化 End
    
		# 更新任务状态
		$db->update(
			'tasklist', # 数据库表名
			[
				'status' => 1 # 更新字段
			],
			[
				'name' => $xls_file_path # where name = {$xls_file_path}
			]
		);

		exit(0); # 任务执行完毕,子进程退出
	}
	# 创建 守护进程 - End
}else{
	# 如果返回负整数(int)就是发生错误了
	$error_msg = [-1=>'上传失败',-2=>'文件存储路径不合法',-3=>'上传非法格式文件',-4=>'文件大小不合符规定',-5=>'token验证错误'];
	echo $error_msg[$filelist];
}
