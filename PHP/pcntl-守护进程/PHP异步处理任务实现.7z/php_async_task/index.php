<?php
include './lib/Medoo.php'; # Medoo 详细使用文档: https://medoo.in/doc
include './function.php';

$db = M(); # 获得数据库操作句柄
$tasklist = $db->select(
	'tasklist', # 数据库表名
	'*'     # 查询字段
);

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>php 异步处理任务</title>
</head>
<body>

<div id="container">

	<!-- 导入文件按钮 Start -->
	<button id="upload_btn">导入Excel数据(.xls)</button> <span id="upload_status"></span>
	<input id="upload_file" type="file" name="file" style="display:none;"/>
	<!-- 导入文件按钮 End -->

	<!-- 任务列表 Start -->
	<table>
		<thead>
			<tr>
				<th>任务名</th>
				<th>任务状态</th>
				<th>操作</th>
			</tr>
		</thead>
		<tbody>
		<!--
			任务有两种状态:
			<tr><td>导入数据1</td><td style="color:red;">已完成</td><td><a href="javascript:;">删除</a></td></tr>
			<tr><td>导入数据1</td><td style="color:red;">处理中</td><td><a href="javascript:;">删除</a></td></tr>
		-->
			<?php foreach($tasklist as $item){ ?>
				<tr>
					<td>导入数据<?php echo $item['name'];?></td>
					<td style="color:red;"><?php echo $item['status'] ? '已完成' : '处理中'; ?></td>
					<td><a href="javascript:;">删除</a></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>
	<!-- 任务列表 End -->

</div>

</body>
<script>
/* _conf 是全局变量 */
_conf = {
	upload_uri:'/recv.php' /* 文件上传URI地址 */
};
</script>

<script src="/js/jquery-1.11.1.min.js"></script>
<!-- 以下插件依赖于jquery, 所以在使用前必须先引用jquery.js -->
<script src="/js/jQueryFileUpload/js/vendor/jquery.ui.widget.js"></script>
<script src="/js/jQueryFileUpload/js/jquery.iframe-transport.js"></script>
<script src="/js/jQueryFileUpload/js/jquery.fileupload.js"></script>

<script>
$(function(){
	/* 监听 导入文件按钮 被点击事件 */
	$('#upload_btn').click(function(){
		$('#upload_file').click(); // 模拟点击隐藏文件表单
	});
	
	/* 监听上传按钮被点击事件 */
	upload_lock = false; // 状态锁 true 正在上传中
	$('#upload_file').fileupload({
        url: _conf.upload_uri,
        dataType:'json', // 上传成功后返回的数据格式
        done:function(e,res){ // 文件上传成功回调
        	//console.log(res.result); // 返回结果
			if(res.result.code===200){
				upload_lock = false;// 解锁状态
				var othis=$('#upload_status'); // 获取状态提示节点对象
				othis.html('上传成功!');
				othis.css('color','#2AC355');
				// 添加任务完成, 这里强制刷新页面
				window.location.reload();
			}else{
				var othis=$('#upload_status'); // 获取状态提示节点对象
				othis.html('上传失败!');
				othis.css('color','#F16192');
			}
        },
        start:function(){ // 文件上传前回调函数
        	upload_lock = true; // 上传文件前上锁, 正在上传中
        },
        progressall:function(e,data){ // 显示上传进度
        	var progress = parseInt(data.loaded / data.total * 100, 10),
        		othis=$('#upload_status'); // 获取状态提示节点对象
        	othis.css('color','#2AC355');
        	othis.html('正在上传.. '+progress+'%');
        }
    });
});
</script>
</html>