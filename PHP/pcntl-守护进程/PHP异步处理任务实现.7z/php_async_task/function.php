<?php
/**
 * 数据库对象初始化函数
 * @param   $dbname 数据库名[optional]
 * @return  $db     PDO对象
 */
function M(){
	static $db=NULL;
	if($db==NULL){ # Medoo 详细使用文档: https://medoo.in/doc
		$db=new \Medoo\Medoo(include './db_conf.php');
	}
	return $db;
}
