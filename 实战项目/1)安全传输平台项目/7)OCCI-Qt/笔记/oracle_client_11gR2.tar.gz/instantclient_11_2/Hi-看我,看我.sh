# 请把已经环境变量设置到对应的文件中
# 可以是当前用户的 ~/.bashrc文件, 也可以是系统的 /etc/profile文件

# OCCI_HOME 该环境变量的路径需要做对应修改
export OCCI_HOME=/opt/instantclient_11_2 
export OCCI_INCLUDE_DIR=$OCCI_HOME/sdk/include
export OCCI_LIBRARY_PATH=$OCCI_HOME 
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$OCCI_LIBRARY_PATH
# 程序编译是搜索的库目录
export LIBRARY_PATH=$LIBRARY_PATH:$OCCI_LIBRARY_PATH
# 程序编译时搜索的头文件目录
export CPLUS_INCLUDE_PATH=$CPLUS_INCLUDE_PATH:$OCCI_INCLUDE_DIR
export NLS_LANG="SIMPLIFIED CHINESE_CHINA.ZHS16GBK"
